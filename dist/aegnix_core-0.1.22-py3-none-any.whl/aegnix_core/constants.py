"""
aegnix_core.constants
---------------------
Shared constants for schema versioning, default sensitivity labels, and policy metadata.
"""

SCHEMA_VERSION = "1.0"
DEFAULT_SENSITIVITY = "UNCLASS"
